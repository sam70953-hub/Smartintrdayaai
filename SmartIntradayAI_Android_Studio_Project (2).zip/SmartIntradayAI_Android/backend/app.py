import os, math, requests
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from flask import Flask, jsonify, render_template

app = Flask(__name__)

# Read-only signals endpoint is consumed by the bundled Android WebView UI.
# Keep this endpoint free of user-specific/private data; use authentication and
# a strict allowlist if you later add account-specific endpoints.
@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Methods"] = "GET, OPTIONS"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    return response
TOKEN = os.getenv("GROWW_ACCESS_TOKEN", "").strip()
BASE = "https://api.groww.in/v1"
HEADERS = {"Accept":"application/json", "Authorization":f"Bearer {TOKEN}", "X-API-VERSION":"1.0"}

# Starter watchlist of liquid NSE names; expand only after testing liquidity and API symbol mapping.
WATCHLIST = ["RELIANCE","HDFCBANK","ICICIBANK","SBIN","INFY","TCS","AXISBANK",
             "LT","BHARTIARTL","ITC","KOTAKBANK","TATAMOTORS","MARUTI","TATASTEEL",
             "BAJFINANCE","HINDUNILVR","SUNPHARMA","ADANIPORTS","ONGC","NTPC"]

def api_get(path, params):
    if not TOKEN:
        raise RuntimeError("Groww access token missing. Set GROWW_ACCESS_TOKEN in your environment.")
    r = requests.get(BASE + path, headers=HEADERS, params=params, timeout=12)
    r.raise_for_status()
    data = r.json()
    if data.get("status") != "SUCCESS":
        raise RuntimeError(str(data))
    return data.get("payload", {})

def candles(symbol):
    now = datetime.now(ZoneInfo("Asia/Kolkata"))
    start = now.replace(hour=9, minute=15, second=0, microsecond=0)
    if now < start:
        start -= timedelta(days=1)
    # Keep request within Groww's documented 5-minute candle window.
    payload = api_get("/historical/candles", {
        "exchange":"NSE", "segment":"CASH", "groww_symbol":f"NSE-{symbol}",
        "start_time":start.strftime("%Y-%m-%d %H:%M:%S"),
        "end_time":now.strftime("%Y-%m-%d %H:%M:%S"),
        "candle_interval":"5minute"
    })
    return payload.get("candles", [])

def ema(values, period):
    if len(values) < period: return None
    k = 2/(period+1)
    out = sum(values[:period])/period
    for x in values[period:]:
        out = x*k + out*(1-k)
    return out

def rsi(values, period=14):
    if len(values) < period+1: return None
    changes = [values[i]-values[i-1] for i in range(1,len(values))]
    gains = sum(max(x,0) for x in changes[-period:])/period
    losses = sum(max(-x,0) for x in changes[-period:])/period
    if losses == 0: return 100.0
    rs = gains/losses
    return 100 - 100/(1+rs)

def analyse(symbol):
    rows = candles(symbol)
    if len(rows) < 25:
        return None
    # Groww candle row: timestamp, open, high, low, close, volume
    close = [float(x[4]) for x in rows]
    high = [float(x[2]) for x in rows]
    low = [float(x[3]) for x in rows]
    vol = [float(x[5]) for x in rows]
    price = close[-1]
    e9, e21, rv = ema(close,9), ema(close,21), rsi(close)
    typical = [(float(x[2])+float(x[3])+float(x[4]))/3 for x in rows]
    cum_pv = sum(typical[i]*vol[i] for i in range(len(rows)))
    cum_vol = sum(vol)
    vwap = cum_pv/cum_vol if cum_vol else price
    avg_vol = sum(vol[-21:-1])/20 if len(vol) >= 21 else 0
    relvol = vol[-1]/avg_vol if avg_vol else 0
    recent_high = max(high[-6:-1])
    recent_low = min(low[-6:-1])

    side = "WAIT"
    score = 0
    if e9 and e21 and rv is not None:
        if price > vwap and e9 > e21 and 52 <= rv <= 70 and relvol >= 1.2 and price > recent_high:
            side, score = "BUY", 5
        elif price < vwap and e9 < e21 and 30 <= rv <= 48 and relvol >= 1.2 and price < recent_low:
            side, score = "SELL", 5
        else:
            score = sum([price > vwap, bool(e9 and e21 and e9 > e21), bool(rv and rv > 50), relvol >= 1.2])
    # ATR-like range estimate from last 14 candles for practical stop sizing
    ranges = [high[i]-low[i] for i in range(max(0,len(rows)-14),len(rows))]
    risk_per_share = max((sum(ranges)/len(ranges))*1.2, price*0.003) if ranges else price*0.005
    if side == "BUY":
        sl, t1, t2 = price-risk_per_share, price+1.5*risk_per_share, price+2*risk_per_share
    elif side == "SELL":
        sl, t1, t2 = price+risk_per_share, price-1.5*risk_per_share, price-2*risk_per_share
    else:
        sl=t1=t2=None
    return {"symbol":symbol,"signal":side,"score":score,"price":round(price,2),
            "entry":round(price,2) if side != "WAIT" else None,
            "stop_loss":round(sl,2) if sl else None,"target1":round(t1,2) if t1 else None,
            "target2":round(t2,2) if t2 else None,"rsi":round(rv,1) if rv is not None else None,
            "vwap":round(vwap,2),"relative_volume":round(relvol,2),
            "note":"Rule-based candidate; confirm candle close, spread and liquidity."}

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/signals")
def signals():
    try:
        results=[]
        errors=[]
        for s in WATCHLIST:
            try:
                item=analyse(s)
                if item: results.append(item)
            except Exception as e:
                errors.append(f"{s}: {str(e)[:120]}")
        results.sort(key=lambda x:(x["signal"]!="WAIT",x["score"],x["relative_volume"]), reverse=True)
        return jsonify({"as_of":datetime.now(ZoneInfo("Asia/Kolkata")).isoformat(),
                        "signals":results[:5],"scanned":len(results),"errors":errors[:3],
                        "capital":25000,"max_risk_per_trade":250})
    except Exception as e:
        return jsonify({"error":str(e),"signals":[]}), 503

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
