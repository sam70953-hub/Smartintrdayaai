# Smart Intraday AI — Android Studio project

## Is package mein kya hai
- Android native wrapper (Kotlin + WebView), portrait mobile layout
- Local bundled dashboard; HTTPS backend URL app ke andar save hota hai
- Groww/NSE 5-minute scanner backend (starter code)
- Signals only: BUY / SELL / WAIT; koi order placement nahi
- Capital ₹25,000; display risk budget ₹250/trade

## APK kaise banayein
1. Android Studio (latest stable) install karein.
2. Is ZIP ko extract karke Android Studio mein `SmartIntradayAI_Android` folder open karein.
3. Gradle sync complete hone dein; Android SDK Platform 35 install karne ka prompt aaye to install karein.
4. Test ke liye phone mein Developer Options + USB debugging enable karke Run karein.
5. APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio generated APK path dikhayega, aam taur par `app/build/outputs/apk/debug/app-debug.apk`.

## Live signals ke liye backend zaroori hai
Android app ke andar Groww token store nahi hota. Flask backend ko HTTPS hosting par deploy karna hoga. Backend environment mein `GROWW_ACCESS_TOKEN` set karein; token ko app, source code, WhatsApp ya ChatGPT mein paste na karein.

Backend files `backend/` folder mein hain. Hosting par Python 3.10+, dependencies in `requirements.txt`, and a production WSGI server (e.g. gunicorn) use karein. Flask development server ko public internet par expose na karein. HTTPS URL app ke Secure backend connection field mein save karein.

## Before live use — mandatory validation
- Groww API account/subscription and token access confirm karein.
- Groww docs ke against endpoint, symbol mapping, candle schema, rate limits and permissions verify karein.
- Current backend is a starter sample watchlist of 20 symbols, not full NSE-market discovery.
- Backend sample adds permissive CORS headers only for its read-only signals endpoint. Do not expose private/account-specific data through this endpoint; add authentication and a strict origin allowlist before extending it.
- Test market-hours, exchange holidays, missing candles, reconnects, API failures and stale data.
- Paper-trade for several weeks including brokerage, taxes, spread and slippage.
- The ₹250 is a planned risk budget, not a guaranteed maximum loss. Quantity calculation and order placement are intentionally not implemented.

## Official Groww references
- https://groww.in/trade-api
- https://groww.in/trade-api/docs/curl/live-data
- https://groww.in/trade-api/docs/curl/backtesting

This source project is not a compiled/signed APK. A local Android Studio build is required. Do not use real money based only on unvalidated signals.
